# Technical Design Document: AI-Powered UI5 Mockup Generator
**Codename:** Stitch5 (working title)
**Status:** Draft v0.1
**Companion doc:** PRD_UI5_AI_Mockup_Tool.md
**Date:** 2026-07-02

---

## 1. Architecture Overview

```
┌────────────┐    ┌───────────────────┐    ┌──────────────┐    ┌────────────────────┐    ┌──────────┐
│  Prompt /  │ →  │ LLM orchestration │ →  │ UI5 XML view │ →  │ Sandboxed UI5       │ →  │ Export   │
│  sketch    │    │ + control catalog │    │ (validated)  │    │ runtime (iframe)    │    │ (project)│
└────────────┘    │ (RAG)             │    └──────────────┘    └────────────────────┘    └──────────┘
                   └───────────────────┘            ↑                     │
                                                     │ selection / edit    │
                                                     └─────────────────────┘
```

Five subsystems, each independently testable:

1. **Control Catalog Service** — source of truth for what's a valid UI5 control.
2. **Generation Orchestrator** — LLM calls, constrained decoding, validation loop.
3. **View Store** — versioned XML view + model state per screen/session.
4. **Render Sandbox** — actual UI5 bootstrap running in an isolated iframe.
5. **Export Service** — packages the session into a real UI5 project.

---

## 2. Control Catalog Service

**Purpose:** ground the LLM so it can only emit controls, properties, aggregations, and events that actually exist in UI5.

**Source data:**
- UI5's public API reference is published as machine-readable JSON (`designtime` and `api.json` per library, e.g. `sap.m`, `sap.f`, `sap.ui.table`).
- SAP already publishes a **UI5 MCP server** for exactly this kind of API-aware tooling — reuse it rather than re-scraping.

**Processing:**
- Parse each control's: name, namespace, properties (with types/defaults/allowed enum values), aggregations (cardinality, allowed control types), associations, events.
- Chunk into a retrieval index keyed by control name and by common **use-case tags** (e.g. "table", "form", "filter", "navigation", "kpi tile") so retrieval can be prompt-driven ("show me controls for a filterable table" → `Table`, `FilterBar`, `Toolbar`, `SearchField`).
- Store canonical **pattern snippets** for common Fiori floorplans (List Report, Object Page, Worklist, Overview Page) as few-shot examples — these encode structural conventions (e.g. object page section layout) that raw control docs don't capture.

**Storage:** a vector index (control descriptions + tags) plus a plain key-value store (control name → full schema) for exact-lookup validation. Refresh on each UI5 version bump; version-pin per project so a mockup doesn't silently shift when UI5 updates.

---

## 3. Generation Orchestrator

**Input:** user prompt (+ optional image), current view state (for edits), floorplan preset (optional).

**Pipeline:**

1. **Retrieval** — pull relevant control schemas + floorplan patterns based on the prompt.
2. **Generation** — LLM call with:
   - System prompt encoding Fiori UX guidelines (spacing, when to use which floorplan, accessibility basics).
   - Retrieved control schemas as grounding context.
   - Structured output target: valid UI5 XML view (use tool-calling / JSON-schema-constrained generation where the "schema" is effectively "must be well-formed XML using only retrieved control names/props").
3. **Validation pass** (non-LLM, deterministic):
   - Parse the XML.
   - Walk every element: does the control exist in the catalog? Are all attributes valid properties for that control? Are child elements valid aggregations?
   - Check basic Fiori lint rules (e.g. object page must have a header; table must have a toolbar if editable).
4. **Repair loop** — if validation fails, feed the specific errors back to the LLM ("control `sap.m.SuperTable` does not exist; did you mean `sap.m.Table`?") and retry, capped at N attempts (e.g. 3) before surfacing an error to the user.
5. **Diff-scoped edits** — for follow-up prompts on an existing view, don't regenerate the whole XML. Instead:
   - Identify the target node(s) via the click-to-select context or prompt intent.
   - Generate a targeted patch (e.g. an XML fragment replacing one control, or a property change).
   - Apply as a tree patch, re-validate only the changed subtree.
   - This keeps unrelated parts of the layout stable across turns — a known pain point with full-regeneration tools.

**Model choice:** any capable LLM works given strong retrieval grounding + validation; the validation/repair loop is what makes hallucination tolerable rather than fatal. Claude/Gemini both fine via API; consider a smaller/faster model for the diff-patch case since scope is narrow.

---

## 4. View Store

- Each mockup session = one or more **screens**, each with:
  - Current XML view (versioned — every accepted edit is a new version, enabling undo/redo).
  - A generated **mock JSON model** matching the data shape implied by the bindings (e.g. if the view binds `{OrderID}`, `{Status}`, the mock model has rows with those fields populated with plausible sample data).
  - Metadata: floorplan type, creation prompt history, control IDs for click-to-select mapping.
- Backing store: simple document store (session → screens → versions). No need for anything heavier than Postgres/JSON columns or even browser-local storage for a v1 single-user tool.

---

## 5. Render Sandbox

**Requirement:** the XML view is LLM output — untrusted. It must render through the real UI5 runtime without ever executing arbitrary attacker-controlled JavaScript.

**Approach:**
- Load the official UI5 bootstrap (`sap-ui-core.js`) inside a **sandboxed `<iframe>`** (`sandbox="allow-scripts"`, no `allow-same-origin`, strict CSP) served from an isolated origin.
- Feed it the generated XML view + mock JSON model via `postMessage`, not by writing to a shared DOM.
- UI5 views are declarative XML — there's no reason to allow `<script>`-equivalent constructs. Strip/reject any `core:require` or event-handler attribute that references anything other than a small allow-listed set of no-op/demo handlers (since v1 has no real business logic, click handlers can just be stubs that highlight the control or show a toast).
- Selection: overlay a transparent click-catcher synced to control DOM IDs so clicking a rendered control in the iframe reports back "user selected `Table#orderTable`" to the host app for the chat context.

This sandbox is the same pattern used for "live preview" panes in any AI-code tool (e.g. Claude's own Artifacts), applied to the UI5 bootstrap instead of arbitrary HTML.

---

## 6. Export Service

**Output:** a standard UI5 app skeleton, e.g.:

```
webapp/
  Component.js
  manifest.json
  i18n/i18n.properties
  view/
    OrdersList.view.xml
    OrderDetail.view.xml
  controller/
    OrdersList.controller.js
    OrderDetail.controller.js
  model/
    mockData.json
  index.html
package.json
ui5.yaml
```

- `manifest.json` generated with routing config matching whatever navigation was implied in multi-screen sessions (Phase 2).
- Controllers are minimal stubs (formatter placeholders, empty event handlers) — enough to open directly in SAP Business Application Studio / VS Code with UI5 tooling and continue real development.
- Export as a downloadable zip in v1; direct Git push / BAS dev-space push in Phase 3.

---

## 7. Tech Stack (proposed)

| Layer | Choice | Why |
|---|---|---|
| Frontend host app | React or plain UI5 web components | Needs to host the iframe sandbox, chat panel, code view |
| LLM orchestration | Server-side (Node/Python) calling Claude/Gemini API | Keeps API keys off client, enables validation loop server-side |
| Control catalog index | Lightweight vector DB (e.g. embedded/local) + KV store | Small, static-ish dataset (a few thousand controls/props) — doesn't need a heavyweight service |
| XML validation | Custom validator against parsed UI5 API JSON | Deterministic, fast, no LLM call needed |
| Render sandbox | Real UI5 bootstrap in sandboxed iframe | Only way to guarantee true fidelity |
| Storage | Postgres (or even SQLite for v1) | Session/version history is simple relational data |
| Export | Zip generation server-side, template-based manifest/controller stubs | Standard, low-risk |

---

## 8. Security Considerations

- **Untrusted XML rendering** is the core risk — mitigated by sandboxed iframe + strict CSP + stripping/allow-listing event-handler references (see §5).
- **Prompt injection via uploaded sketches/screenshots** (e.g. an image containing embedded text instructing the model to do something unintended) — treat OCR'd/extracted text from images as untrusted input, not as elevated instructions.
- **No arbitrary code execution path** should exist end-to-end: the LLM never generates JS that the browser executes directly; it only generates declarative XML + a mock data JSON, both of which pass through the deterministic validator before rendering.
- **Export integrity** — generated controller stubs should contain no dynamic `eval`/`Function()` constructs; keep them template-based, not LLM-authored, in v1.

---

## 9. Testing Strategy

- **Golden-set eval:** curate ~100 prompts across floorplans (list report, object page, worklist, overview page) with expected control sets; run generation nightly, track control-validity rate and floorplan-adherence score (ties to PRD success metric).
- **Validator unit tests:** every control/property/aggregation rule in the catalog gets a positive and negative test case.
- **Sandbox security tests:** attempt known iframe-escape and CSP-bypass patterns as part of CI.
- **Regression on diff-patch:** verify that an edit to one control never perturbs unrelated XML nodes (byte-level diff of the unaffected subtree).

---

## 10. Phased Delivery (technical)

| Phase | Scope |
|---|---|
| 1 — MVP | Single-screen generation, 4 floorplans, `sap.m` only, sandboxed render, chat edits, zip export |
| 2 | Multi-screen + routing, XML import, design-system extraction from an existing app |
| 3 | Real OData v4 metadata import, direct BAS/Git push, IDE extension surface |

---

## 11. Open Technical Questions

- Constrained decoding: use provider-native structured output (tool calling with an XML/JSON schema) vs. a self-hosted grammar-constrained model? Affects latency and portability.
- How much of Fiori's design guidance (spacing, floorplan choice heuristics) can be captured as retrieval context vs. needs a dedicated lint/scoring model?
- Where does the sandbox iframe get hosted for enterprise customers with strict network isolation requirements (BTP-internal vs. public CDN for the UI5 bootstrap)?
