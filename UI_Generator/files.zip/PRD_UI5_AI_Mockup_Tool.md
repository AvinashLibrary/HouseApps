# PRD: AI-Powered UI5 Mockup Generator
**Codename:** Stitch5 (working title)
**Status:** Draft v0.1
**Owner:** [TBD]
**Date:** 2026-07-02

---

## 1. Summary

An AI tool that turns a text prompt (or a rough sketch) into a live, working mockup built entirely from real SAPUI5/OpenUI5 controls — not a lookalike image, not a generic HTML approximation. The output renders through the actual UI5 runtime and exports as a runnable UI5 app skeleton (`webapp/`, `manifest.json`, XML views) that developers can carry straight into SAP Business Application Studio, VS Code, or Claude Code.

Think "Google Stitch," but the LLM is constrained to the real UI5 control catalog, so what you see in the mockup is pixel-and-behavior identical to what ships.

## 2. Problem Statement

Today, teams designing SAP Fiori/UI5 applications have to choose between:

| Tool | Speed | Fidelity to real UI5 | Code output |
|---|---|---|---|
| Figma + Fiori UI Kit | Fast | Low — static vector lookalikes, drifts from real control behavior | None |
| SAP Build | Medium — manual drag/drop | High — real controls | Exportable, but not AI-generated |
| Axure + Fiori stencils | Slow | Low — static wireframes | None |
| Hand-coding a UI5 prototype | Slow | Perfect | Full code, but expensive iteration |
| Google Stitch | Very fast (AI) | None — generic HTML/Tailwind/React | Code, but wrong framework entirely |

Nobody combines **AI speed** with **real UI5 fidelity**. Designers either get speed and lose accuracy (Figma, Stitch) or get accuracy and lose speed (SAP Build, hand-coding). This forces a re-translation step later — someone has to rebuild the "pretty" Figma mockup as an actual UI5 app, and details get lost or reinterpreted in that handoff.

## 3. Goals

- **G1:** Generate a working UI5 mockup from a natural-language prompt in under 60 seconds.
- **G2:** Every control in the output is a real, valid `sap.m` / `sap.f` / `sap.ui.table` control — no invented properties, no non-existent aggregations.
- **G3:** The mockup renders through the genuine UI5 runtime, so what's shown is exactly what a developer will get.
- **G4:** Support iterative refinement via chat ("make the table read-only", "add a filter bar") without regenerating the whole screen.
- **G5:** Export a real UI5 project (manifest, views, mock OData/JSON model) that opens directly in SAP BAS / VS Code with the UI5 tooling.
- **G6:** Support common Fiori floorplans out of the box (list report, object page, worklist, overview page) as generation targets, not just free-form screens.

### Non-Goals (v1)
- Not a full low-code app builder with real backend/OData binding to production systems (mock data only in v1).
- Not a pixel-level custom-branding/theme designer — v1 uses standard Horizon theme.
- Not a replacement for SAP Build's process/data modeling capabilities.
- No multi-user real-time collaboration in v1 (single-user session).

## 4. Target Users

1. **Fiori/UX designers** at SAP consultancies or in-house SAP teams who currently mock up in Figma using the Fiori kit and hand off to developers.
2. **UI5 developers** who want to scaffold a screen fast instead of hand-writing XML views from scratch.
3. **Solution architects / pre-sales** who need to demo realistic Fiori app concepts to clients quickly.
4. **Citizen developers** on SAP BTP who know roughly what they want but not UI5 syntax.

## 5. Key Use Cases

- **UC1 — Blank-canvas generation:** "Create a list report for tracking sales orders with columns for order ID, customer, status, and amount." → working list-report screen.
- **UC2 — Floorplan-first generation:** User picks "Object Page" floorplan, describes the entity → tool scaffolds header, sections, and relevant controls.
- **UC3 — Iterative refinement:** User asks follow-up changes in chat; only the affected part of the XML view updates, layout elsewhere is preserved.
- **UC4 — Import existing screen:** User pastes an existing UI5 XML view; tool renders it live and allows prompt-driven edits.
- **UC5 — Multi-screen flow:** User describes a flow ("list report → click a row → object page") and the tool generates linked screens with basic navigation wired up.
- **UC6 — Export & handoff:** User exports the project; a developer opens it in SAP Business Application Studio and continues with real data binding.

## 6. Functional Requirements

### MVP (Phase 1)
- FR1: Prompt-to-screen generation for single screens using core `sap.m` controls (Table, List, Form, ObjectHeader, IconTabBar, Bar, Button, Input, etc.)
- FR2: Live rendering via actual UI5 bootstrap in a sandboxed iframe, using a generated mock JSON model.
- FR3: Chat-based iterative editing with diff-scoped regeneration (not full re-generation per turn).
- FR4: Click-to-select any rendered control to see its properties and ask for targeted changes.
- FR5: Export to a downloadable UI5 project folder (manifest.json, Component.js, one or more XML views, i18n file, mock model JSON).
- FR6: Validation layer — every generated control/property checked against the real UI5 API before rendering; invalid output triggers automatic self-correction retry.
- FR7: Support for the 4 most common floorplans as generation presets: List Report, Object Page, Worklist, Overview Page.

### Phase 2
- FR8: Multi-screen flows with basic navigation (router config generated alongside views).
- FR9: Import of existing XML views/screens for AI-assisted editing.
- FR10: Design system extraction — point at an existing UI5 app and match its patterns/spacing conventions in new generations.
- FR11: Team library — save, tag, and share generated screens within an org.

### Phase 3 (future)
- FR12: Real OData v4 metadata import to replace mock data with live-shaped data.
- FR13: Direct push to a Git repo / SAP BAS dev space.
- FR14: Plugin/extension inside SAP Business Application Studio and VS Code.

## 7. UX Flow (MVP)

1. User lands on a blank canvas + prompt bar (optionally picks a floorplan preset first).
2. User types a prompt or uploads a sketch/screenshot.
3. Screen streams in on canvas, rendered live (not a static image).
4. User refines via chat, or clicks a control directly and asks for a targeted change ("make this a MultiComboBox").
5. User can toggle "Code view" to see the underlying XML view at any time.
6. User exports the project as a zip or pushes to a connected repo.

## 8. Success Metrics

| Metric | Target (6 months post-launch) |
|---|---|
| Time from prompt to first rendered screen | < 60s p50 |
| % of generations requiring zero manual XML fixes before dev handoff | > 70% |
| Weekly active designers/developers | [TBD by business] |
| % of exported projects opened in SAP BAS/VS Code within 7 days | Leading indicator of real adoption |
| Control-validity rate (generated controls that are real & valid) | > 99% |

## 9. Constraints & Assumptions

- Assumes access to an LLM capable of structured/constrained generation (function calling or grammar-constrained decoding) to keep output within valid UI5 syntax.
- Assumes the UI5 control metadata (properties, aggregations, associations, events) can be extracted programmatically from the UI5 API reference / TypeScript typings — this already exists via the public UI5 API JSON and the UI5 MCP server SAP publishes.
- v1 targets `sap.m` (mobile/responsive) library only; `sap.ui.table`, `sap.f`, and other libraries considered post-MVP.
- Rendering must happen in a sandboxed context — generated XML is untrusted input from an LLM and should never execute arbitrary JS.

## 10. Risks

| Risk | Mitigation |
|---|---|
| LLM hallucinates non-existent controls/properties | Hard validation pass against real UI5 metadata before render; auto-retry with error fed back to LLM |
| Generated screens don't match real Fiori UX guidelines (accessibility, spacing conventions) | Bake Fiori design guidelines into the system prompt / retrieval context; add a lint pass |
| Users expect real data binding immediately | Set expectations clearly in UX copy — v1 is mock-data only |
| Complex multi-screen flows produce inconsistent navigation | Scope multi-screen to Phase 2, start with single-screen only |
| SAP could ship an official competing feature (Joule-based) | Move fast, focus on iteration speed and dev handoff quality as differentiators |

## 11. Open Questions

- Which LLM(s) power generation — hosted Claude/Gemini via API, or an on-prem/BTP-hosted option for customers with data residency requirements?
- Does this live as a standalone web app, or as an extension inside SAP Business Application Studio / VS Code from day one?
- Licensing/distribution model — internal tool, open-source, or commercial SAP BTP add-on?
